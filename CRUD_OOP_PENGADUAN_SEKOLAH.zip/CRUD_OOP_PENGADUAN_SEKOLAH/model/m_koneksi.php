<?php

class Koneksi
{
    private $host = "127.0.0.1";
    private $username = "root";
    private $password = "root";
    private $database = "pengaduan_sekolah";

    protected $conn;

    public function __construct()
    {
        try {

            $this->conn = new PDO(
                "mysql:host=" . $this->host .
                ";dbname=" . $this->database .
                ";charset=utf8",
                $this->username,
                $this->password
            );

            $this->conn->setAttribute(
                PDO::ATTR_ERRMODE,
                PDO::ERRMODE_EXCEPTION
            );

        } catch (PDOException $e) {

            die("Koneksi database gagal: " . $e->getMessage());

        }
    }

    public function getConnection()
    {
        return $this->conn;
    }
}
?>