<?php

session_start();


if (!isset($_SESSION['id'])) {

    header("Location: v_login.php");

    exit;
}


if ($_SESSION['role'] != "siswa") {

    header("Location: v_login.php");

    exit;
}


$nama =
    $_SESSION['nama'];

$kelas =
    $_SESSION['kelas'];

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Dashboard Siswa</title>


    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;

            font-family:
                Arial,
                Helvetica,
                sans-serif;
        }


        body {
            background: #f4f7fb;
        }


        .sidebar {

            position: fixed;

            left: 0;
            top: 0;

            width: 250px;

            height: 100vh;

            background: #0F1035;

            padding: 25px 18px;
        }


        .logo {

            color: white;

            text-align: center;

            font-size: 20px;

            font-weight: bold;

            margin-bottom: 40px;
        }


        .menu-title {

            color: #999;

            font-size: 12px;

            margin:
                20px 12px 10px;
        }


        .menu a {

            display: block;

            color: #ddd;

            text-decoration: none;

            padding: 13px 15px;

            border-radius: 8px;

            margin-bottom: 7px;
        }


        .menu a:hover,
        .menu .active {

            background: #365486;

            color: white;
        }


        .logout {

            position: absolute;

            bottom: 25px;

            left: 18px;
            right: 18px;
        }


        .logout a {

            display: block;

            text-align: center;

            padding: 12px;

            border-radius: 8px;

            background: #d9534f;

            color: white;

            text-decoration: none;
        }


        .content {

            margin-left: 250px;

            padding: 30px;
        }


        .topbar {

            display: flex;

            justify-content:
                space-between;

            align-items: center;

            margin-bottom: 25px;
        }


        .topbar h1 {

            color: #0F1035;

            font-size: 28px;
        }


        .profile {

            background: white;

            padding:
                11px 18px;

            border-radius: 10px;

            box-shadow:
                0 3px 10px
                rgba(0,0,0,0.07);
        }


        .welcome {

            background:
                linear-gradient(
                    135deg,
                    #365486,
                    #7FC7D9
                );

            color: white;

            padding: 30px;

            border-radius: 15px;

            margin-bottom: 25px;
        }


        .welcome h2 {

            margin-bottom: 10px;
        }


        .cards {

            display: grid;

            grid-template-columns:
                repeat(3, 1fr);

            gap: 20px;

            margin-bottom: 25px;
        }


        .card {

            background: white;

            padding: 25px;

            border-radius: 15px;

            text-decoration: none;

            color: #333;

            box-shadow:
                0 4px 12px
                rgba(0,0,0,0.07);
        }


        .card:hover {

            transform:
                translateY(-4px);
        }


        .icon {

            width: 50px;

            height: 50px;

            display: flex;

            align-items: center;

            justify-content: center;

            background: #DCF2F1;

            border-radius: 10px;

            font-size: 23px;

            margin-bottom: 15px;
        }


        .card h3 {

            color: #0F1035;

            margin-bottom: 8px;
        }


        .card p {

            color: #777;

            font-size: 14px;

            line-height: 1.5;
        }


        .info {

            background: white;

            padding: 25px;

            border-radius: 15px;

            box-shadow:
                0 4px 12px
                rgba(0,0,0,0.07);
        }


        .info h3 {

            color: #0F1035;

            margin-bottom: 15px;
        }


        .info-row {

            display: flex;

            justify-content:
                space-between;

            padding: 13px 0;

            border-bottom:
                1px solid #eee;
        }


        @media (max-width: 900px) {

            .sidebar {
                width: 210px;
            }

            .content {
                margin-left: 210px;
            }

            .cards {
                grid-template-columns: 1fr;
            }

        }

    </style>

</head>


<body>


<div class="sidebar">


    <div class="logo">
        PENGADUAN SEKOLAH
    </div>


    <div class="menu-title">
        MENU SISWA
    </div>


    <div class="menu">


        <a
            href="v_dashboard_siswa.php"
            class="active"
        >
            🏠 Dashboard
        </a>


        <a href="v_pengaduan.php">
            📝 Mengirim Pengaduan
        </a>


        <a href="v_status_pengaduan.php">
            📋 Status Pengaduan
        </a>


        <a href="v_umpan_balik.php">
            💬 Umpan Balik
        </a>


    </div>


    <div class="logout">

        <a href="logout.php">
            Logout
        </a>

    </div>


</div>


<div class="content">


    <div class="topbar">

        <h1>
            Dashboard
        </h1>


        <div class="profile">

            👤
            <?php
            echo htmlspecialchars($nama);
            ?>

        </div>

    </div>


    <div class="welcome">

        <h2>

            Selamat Datang,
            <?php
            echo htmlspecialchars($nama);
            ?>!

        </h2>


        <p>

            Selamat datang di Sistem Pengaduan
            Sarana Prasarana Sekolah.

        </p>

    </div>


    <div class="cards">


        <a
            href="v_pengaduan.php"
            class="card"
        >

            <div class="icon">
                📝
            </div>

            <h3>
                Mengirim Pengaduan
            </h3>

            <p>
                Kirim pengaduan mengenai sarana
                dan prasarana sekolah.
            </p>

        </a>


        <a
            href="v_status_pengaduan.php"
            class="card"
        >

            <div class="icon">
                📋
            </div>

            <h3>
                Status Pengaduan
            </h3>

            <p>
                Lihat status pengaduan yang
                telah kamu kirim.
            </p>

        </a>


        <a
            href="v_umpan_balik.php"
            class="card"
        >

            <div class="icon">
                💬
            </div>

            <h3>
                Umpan Balik
            </h3>

            <p>
                Lihat tanggapan dari admin.
            </p>

        </a>


    </div>


    <div class="info">

        <h3>
            Informasi Akun
        </h3>


        <div class="info-row">

            <span>
                Nama
            </span>

            <strong>
                <?php
                echo htmlspecialchars($nama);
                ?>
            </strong>

        </div>


        <div class="info-row">

            <span>
                Kelas
            </span>

            <strong>
                <?php
                echo htmlspecialchars($kelas);
                ?>
            </strong>

        </div>


        <div class="info-row">

            <span>
                Role
            </span>

            <strong>
                Siswa
            </strong>

        </div>


    </div>


</div>


</body>

</html>