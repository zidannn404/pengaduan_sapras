<?php

require_once "../model/m_koneksi.php";

$koneksi = new Koneksi();
$db = $koneksi->getConnection();

$pesan = "";

if (isset($_POST['registrasi'])) {

    $nama     = trim($_POST['nama']);
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $kelas    = trim($_POST['kelas']);

    // Cek semua input
    if (
        $nama == "" ||
        $username == "" ||
        $password == "" ||
        $kelas == ""
    ) {

        $pesan = "Semua data harus diisi!";

    } else {

        // Cek username
        $cek = $db->prepare(
            "SELECT id FROM users WHERE username = :username"
        );

        $cek->execute([
            ':username' => $username
        ]);

        if ($cek->rowCount() > 0) {

            $pesan = "Username sudah digunakan!";

        } else {

            // Password di-hash
            $password_hash = password_hash(
                $password,
                PASSWORD_DEFAULT
            );

            // Role otomatis siswa
            $role = "siswa";

            // Simpan data
            $stmt = $db->prepare(
                "INSERT INTO users
                (nama, username, password, role, kelas)
                VALUES
                (:nama, :username, :password, :role, :kelas)"
            );

            $berhasil = $stmt->execute([
                ':nama'     => $nama,
                ':username' => $username,
                ':password' => $password_hash,
                ':role'     => $role,
                ':kelas'    => $kelas
            ]);

            if ($berhasil) {

                echo "<script>
                    alert('Registrasi berhasil! Silakan login.');
                    window.location.href = 'v_login.php';
                </script>";

                exit;

            } else {

                $pesan = "Registrasi gagal!";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Registrasi Siswa</title>

<style>

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
}

body {
    min-height: 100vh;

    display: flex;
    justify-content: center;
    align-items: center;

    background: linear-gradient(
        135deg,
        #365486,
        #7FC7D9
    );
}

.container {
    width: 100%;
    max-width: 430px;
    padding: 20px;
}

.card {
    background: white;

    padding: 35px;

    border-radius: 20px;

    box-shadow:
        0 15px 40px rgba(0,0,0,0.20);
}

.judul {
    text-align: center;

    color: #0F1035;

    font-size: 28px;

    margin-bottom: 8px;
}

.subjudul {
    text-align: center;

    color: #777;

    font-size: 14px;

    margin-bottom: 25px;
}

.pesan {
    background: #ffe5e5;

    color: #c62828;

    padding: 10px;

    border-radius: 8px;

    text-align: center;

    font-size: 14px;

    margin-bottom: 15px;
}

.form-group {
    margin-bottom: 17px;
}

label {
    display: block;

    margin-bottom: 7px;

    font-size: 14px;

    font-weight: bold;

    color: #333;
}

input {
    width: 100%;

    padding: 13px;

    border: 1px solid #ddd;

    border-radius: 10px;

    outline: none;

    font-size: 14px;
}

input:focus {
    border-color: #365486;
}

.password-box {
    position: relative;
}

.password-box input {
    padding-right: 45px;
}

.mata {
    position: absolute;

    right: 13px;

    top: 50%;

    transform: translateY(-50%);

    cursor: pointer;

    font-size: 18px;
}

.btn {
    width: 100%;

    padding: 13px;

    border: none;

    border-radius: 10px;

    background: #365486;

    color: white;

    font-size: 15px;

    font-weight: bold;

    cursor: pointer;
}

.btn:hover {
    background: #29436f;
}

.login {
    text-align: center;

    margin-top: 20px;

    font-size: 14px;

    color: #777;
}

.login a {
    color: #365486;

    font-weight: bold;

    text-decoration: none;
}

</style>

</head>

<body>

<div class="container">

<div class="card">

<h1 class="judul">
    Buat Akun
</h1>

<p class="subjudul">
    Registrasi akun siswa
</p>


<?php if ($pesan != "") { ?>

<div class="pesan">
    <?= htmlspecialchars($pesan); ?>
</div>

<?php } ?>


<form method="POST"
      action="v_registrasi.php">


<!-- Nama -->

<div class="form-group">

<label>
    Nama Lengkap
</label>

<input
    type="text"
    name="nama"
    placeholder="Masukkan nama lengkap"
    required
>

</div>


<!-- Username -->

<div class="form-group">

<label>
    Username
</label>

<input
    type="text"
    name="username"
    placeholder="Masukkan username"
    required
>

</div>


<!-- Password -->

<div class="form-group">

<label>
    Password
</label>

<div class="password-box">

<input
    type="password"
    name="password"
    id="password"
    placeholder="Masukkan password"
    required
>

<span
    class="mata"
    id="mata"
    onclick="lihatPassword()"
>
    👁
</span>

</div>

</div>


<!-- Kelas -->

<div class="form-group">

<label>
    Kelas
</label>

<input
    type="text"
    name="kelas"
    placeholder="Contoh: XI RPL 1"
    required
>

</div>


<!-- Tombol -->

<button
    type="submit"
    name="registrasi"
    class="btn"
>
    Daftar Sekarang
</button>

</form>


<div class="login">

Sudah punya akun?

<a href="v_login.php">
    Login
</a>

</div>

</div>

</div>


<script>

function lihatPassword() {

    let password =
        document.getElementById("password");

    let mata =
        document.getElementById("mata");

    if (password.type === "password") {

        password.type = "text";

        mata.innerHTML = "🙈";

    } else {

        password.type = "password";

        mata.innerHTML = "👁";
    }
}

</script>

</body>

</html>