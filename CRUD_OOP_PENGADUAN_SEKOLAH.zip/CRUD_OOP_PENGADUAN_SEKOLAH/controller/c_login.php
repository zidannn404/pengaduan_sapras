<?php

session_start();

require_once "../model/m_koneksi.php";

$koneksi = new Koneksi();
$db = $koneksi->getConnection();


if (isset($_POST['login'])) {

    $username = trim($_POST['username']);
    $password = $_POST['password'];


    $query = "
        SELECT *
        FROM users
        WHERE username = :username
        LIMIT 1
    ";

    $stmt = $db->prepare($query);

    $stmt->bindParam(
        ":username",
        $username
    );

    $stmt->execute();

    $user = $stmt->fetch(PDO::FETCH_ASSOC);


    if (
        $user &&
        password_verify(
            $password,
            $user['password']
        )
    ) {

        // Membuat session
        $_SESSION['id']       = $user['id'];
        $_SESSION['nama']     = $user['nama'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role']     = $user['role'];
        $_SESSION['kelas']    = $user['kelas'];


        // =========================
        // LOGIN ADMIN
        // =========================

        if ($user['role'] == "admin") {

            header(
                "Location: ../view/v_dashboard_admin.php"
            );

            exit;
        }


        // =========================
        // LOGIN SISWA
        // =========================

        if ($user['role'] == "siswa") {

            header(
                "Location: ../view/v_dashboard_siswa.php"
            );

            exit;
        }


        // Jika role tidak dikenal
        session_destroy();

        header(
            "Location: ../view/v_login.php?error=role"
        );

        exit;

    } else {

        // Username/password salah
        header(
            "Location: ../view/v_login.php?error=1"
        );

        exit;
    }

}

?>